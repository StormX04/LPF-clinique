
<?php



$reqMedInfo = 'Select Nom, Prenom, personnel.ID FROM personnel LEFT JOIN hospitalisation ON personnel.ID = hospitalisation.Choix_medecin WHERE hospitalisation.Choix_medecin IS NULL AND personnel.ID !='.$activeUsr.';';
$resultMed = mysqli_query($conn, $reqMedInfo);
echo '<div id="PersonnelAction" class="baseContentStyle">';
echo '<label for="montrelePerso" style="padding-right : 0.7%;">Suppression / Modification d\'un membre du personnel : </label>';
echo '<div id="persosuppr" ><form method="post" action="tableau_de_bord.php"><label for="personnel-choix" style="padding-left : 4.5%;">Sélectionner un membre du personnel : </label><select name="personnelSuppr" id="personnel-choix" value=""><option value="">--Choisissez un personnel--</option>';
while($colonn = mysqli_fetch_array($resultMed, MYSQLI_ASSOC)){
	echo '<option value="'.$colonn['ID'].'">'.$colonn["Nom"].' '.$colonn["Prenom"].'</option>' ;
}
echo'</select>
<input type="submit" id="idMed" onclick="return choix(\'personnel\')" value="Supprimer"> 
</form></div>';// <input id="userID" type="hidden" name="userID" value="'.$_SESSION['identifiant'].'">  <input id="mdp" type="hidden" name="mdp" value="'.$_SESSION['lemdp'].'">

$reqMedModif = 'Select Nom, Prenom, personnel.ID FROM personnel WHERE personnel.ID !='.$activeUsr.';';
$resultMedModif = mysqli_query($conn, $reqMedModif);
echo '<div id="persomodif" ><form method="post" action="tableau_de_bord.php"><label for="personnelM-choix" style="padding-left : 4.5%;">Sélectionner un membre du personnel : </label><select name="personnelM" id="personnelM-choix" value=""><option value="">--Choisissez un personnel--</option>';
while($colonn = mysqli_fetch_array($resultMedModif, MYSQLI_ASSOC)){
	echo '<option value="'.$colonn['ID'].'">'.$colonn["Nom"].' '.$colonn["Prenom"].'</option>' ;
}
echo'</select>
<input type="submit" id="idMed" onclick="" value="Modifier"> 
</form></div>';
$recupinfo = array();


if(isset($_POST['personnelSuppr'])) {
	$requete = 'DELETE FROM clinique_lpf.personnel WHERE ID='.$_POST['personnelSuppr'].';';
	$resultest = mysqli_query($conn, $requete);
	echo'<script type="text/javascript">window.location.assign(\'tableau_de_bord.php\');</script>';
}

$reqServInfo = 'Select * FROM service ;';
$resultServ = mysqli_query($conn, $reqServInfo);
echo '<label for="PersoAjout" style="padding-right : 0.7%;">Ajout d\'un membre du personnel : </label>';
echo'
<div id="persoajt" >
<form method="post" action="tableau_de_bord.php">
<label for="nomPerso">Nom :</label>
<input id="nomPerso" type="text" name="nomPerso">
<label for="prenomPerso">Prenom :</label>
<input id="prenomPerso" type="text" name="prenomPerso">
<label for="service-choix-P" style="padding-left : 1%;">Sélectionner un service : </label><select name="service-P" id="service-choix-P" value=""><option value="">--Choisissez un service--</option>';
while($colonn = mysqli_fetch_array($resultServ, MYSQLI_ASSOC)){
	echo '<option value="'.$colonn['ID'].'">'.$colonn["libelle"].'</option>' ;
}
// faire du js pour la politique de mot de passe et donc l'écrire
echo'</select> <br>
<label for="mdpPerso">Son mot de passe :</label>
<input id="mdpPerso" type="text" name="mdpPerso">
<label for="role-choix-P" style="padding-left : 1%;">Sélectionner un rôle : </label><select name="role-P" id="role-choix-P" value=""><option value="">--Choisissez un rôle--</option>';
echo '<option value="1">secrétaire</option>' ;
echo '<option value="3">médecin</option>' ;

echo'</select>
<input type="submit" value="Ajouter"> 
</form></div>  <br> ';

echo'</div>';
if(isset($_POST['nomPerso']) && !empty($_POST['nomPerso'])) {
	$reqAJTPerso = "INSERT INTO clinique_lpf.personnel (Nom, Prenom, id_service) VALUES('".$_POST['nomPerso']."', '".$_POST['prenomPerso']."', ".$_POST['service-P']."); ";
	mysqli_query($conn, $reqAJTPerso);
	$reqPinfo = 'Select ID FROM personnel WHERE Nom ="'.$_POST['nomPerso'].'" AND Prenom="'.$_POST['prenomPerso'].'" AND id_service='.$_POST['service-P'].' LIMIT 1 ;';
	$resultPinfo = mysqli_query($conn, $reqPinfo);
	$identifiant = substr($_POST['nomPerso'],0,2).".".substr($_POST['prenomPerso'],0,2)."_LPF";
	while($colonn = mysqli_fetch_array($resultPinfo, MYSQLI_ASSOC)){
		$reqAJTAuthen = "INSERT INTO clinique_lpf.authentification (nom_utilisateur, Motdepasse, Id_personnel, Id_permissions) VALUES('".$identifiant."', SHA1('".$_POST['mdpPerso'].")', ".$colonn['ID'].", ".$_POST['role-P']."); ";
		mysqli_query($conn, $reqAJTAuthen);
		echo'<script type="text/javascript">alert("Voici les informations de connexion de l\'utilisateur créer  identifiant : '.$identifiant.' Son mot de passe : '.$_POST['mdpPerso'].'");</script>';
		echo'<script type="text/javascript">window.location.assign(\'tableau_de_bord.php\');</script>';
}
}
echo'</div></div>';

if(isset($_POST['personnelM'])) {
	$reqModifPerso = 'Select personnel.ID ,personnel.Nom, personnel.Prenom, personnel.id_service, service.libelle FROM clinique_lpf.personnel INNER JOIN service ON personnel.id_service = service.ID WHERE personnel.ID='.$_POST['personnelM'].';';
	$resulModifPerso = mysqli_query($conn, $reqModifPerso);
	$recupinfo  = mysqli_fetch_array($resulModifPerso, MYSQLI_ASSOC);
	$reqServM = 'Select * FROM service WHERE id !="'.$recupinfo["id_service"].'";';
	$resultServM = mysqli_query($conn, $reqServM);
	echo'
	<div id="persoModif" class="modifPerso" >
	<span class="baseText"> Modification du personnel choisi : </span>
	<form method="post" action="tableau_de_bord.php">
	<label for="nomModif">Nom :</label>
	<input id="nomModif" type="text" name="nomModif" value="'.$recupinfo["Nom"].'">
	<label for="prenomModif">Prenom :</label>
	<input id="idModif" type="hidden" name="idModif" value="'.$recupinfo["ID"].'">
	<input id="prenomModif" type="text" name="prenomModif" value="'.$recupinfo["Prenom"].'">
	<br><br><label for="service-choix-M" style="padding-left : 1%;">Changer le service : </label><select name="service-M" id="service-choix-M" value=""><option value="'.$recupinfo["id_service"].'">'.$recupinfo["libelle"].'</option>';
	while($colonn = mysqli_fetch_array($resultServM, MYSQLI_ASSOC)){
		echo '<option value="'.$colonn['ID'].'">'.$colonn["libelle"].'</option>' ;
	}
	echo'</select> 
	<input type="submit" value="Modifier"> 
	</form></div> ';


	//echo'<script type="text/javascript">window.location.assign(\'tableau_de_bord.php\');</script>';
}
if(isset($_POST['nomModif'])) {
	$requeteModif = 'UPDATE clinique_lpf.personnel SET Nom="'.$_POST['nomModif'].'", Prenom="'.$_POST['prenomModif'].'", id_service='.$_POST['service-M'].' WHERE ID='.$_POST['idModif'].'; ';
	$resulModif = mysqli_query($conn, $requeteModif);
	echo'<script type="text/javascript">window.location.assign(\'tableau_de_bord.php\');</script>';
}


?>

