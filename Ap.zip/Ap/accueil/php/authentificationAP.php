<?php
error_reporting(E_ALL & ~E_NOTICE);
ini_set("display_errors",1);
session_start(); 
if($_POST['userID'] != '' &&  $_POST['mdp'] != '' && $_POST['captcha'] == $_POST['codeT']) {
    $_SESSION['identifiant'] = $_POST['userID'];
    $_SESSION['lemdp'] = $_POST['mdp'];
    header('Location: /Ap/accueil/tableau_de_bord.php');
    die();
}else { 
	setcookie("erreur","erreur", time()+60 ,"/");
	header('Location: /Ap/');
	exit;
}

/*
$requete = 'Select * FROM personnel ;';
$result = mysqli_query($conn, $requete);
while($colonn = mysqli_fetch_array($result, MYSQLI_ASSOC)){
    print_r( $colonn) ;
}*/


?>
