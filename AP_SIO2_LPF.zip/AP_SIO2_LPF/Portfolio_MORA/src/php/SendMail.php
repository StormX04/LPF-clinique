<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['fname'];
    $mail = $_POST['mail'];
    $object = $_POST['object'];
    $message = $_POST['message'];
    if (empty($name)) {
        echo "Name is empty";
    } else {
        echo $name;
        echo $mail;
        echo $object;
        echo $message;
    }
}

?>


