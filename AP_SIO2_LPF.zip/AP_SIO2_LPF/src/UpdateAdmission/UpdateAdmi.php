<!DOCTYPE html>
<html lang="Fr">
<head>
    <meta charset="UTF-8">
    <title>Verification client</title>
</head>

<body>
<header>
    <div class="logo"></div>
</header>
<h1 class="red TitlePreAdmi">Modification Admission</h1>

<section class="group_form">

</section>
</body>
</html>