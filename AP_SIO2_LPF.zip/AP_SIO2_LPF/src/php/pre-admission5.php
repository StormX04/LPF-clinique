<?php
include 'Requete.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fi_Mutuelle = $_POST['Fi_Mutuelle'];
        $fi_Carte_Vitale = $_POST['Fi_Carte_vitale'];
        $fi_Livret_famille = $_POST['Fi_Livret_famille'];
        $fi_autorisation = $_POST['Fi_autorisation'];

        $_SESSION['Fi_Mutuelle'] = $fi_Mutuelle;
        $_SESSION['Fi_Carte_vitale'] =  $fi_Carte_Vitale;
        $_SESSION['Fi_Livret_famille'] = $fi_Livret_famille;
        $_SESSION['Fi_autorisation'] = $fi_autorisation;
    }
    var_dump($_SESSION);
    $Patient = array($_SESSION['Numero_secu_social'], $_SESSION['civilite'],  $_SESSION['nom_naissance'], $_SESSION['nom_epouse'], $_SESSION['Prenom'],$_SESSION['Date_naissance'],$_SESSION['adresse'],$_SESSION['Cp'],$_SESSION['Ville'], $_SESSION['Email'],$_SESSION['Telephone'],$_SESSION['Numero_secu_social'],$_SESSION['Numero_secu_social'],$_SESSION['Numero_secu_social'],$_SESSION['Numero_secu_social'],$_SESSION['Numero_secu_social'],$_SESSION['Numero_secu_social']);
    InsrtPatient($Patient)



?>
<!--//    var_dump($ContactPrevenir[0]);-->
<!--//-->
<!--//    foreach ($ContactPrevenir as $val) {-->
<!--//        echo "$val <br>";-->
<!--//    }-->

<!--$Hospitalisation = $_SESSION['Hospitalisation'];-->
<!--$Patient = $_SESSION['Patient'];-->
<!--$ContactPrevenir =   $_SESSION['ContactPrevenir'];-->
<!--$ContactConfiance = $_SESSION['ContactConfiance'];-->
<!--$CouvertureSocial = $_SESSION['CouvertureSocial'];-->
<!--$Fichier = $_SESSION['Fichier'];-->



